const { escapeHtml } = require('./../utils.js');
const wordsRow = require('./wordsRow.js');

const needData = ['getTranslationsByWord'];

function render(opts) {
  const [data] = opts.data;
  const rows = Object.entries(data).map(([key, value]) => {
    return wordsRow.render({key, value});
  }).join('\n');

  return `
    <table class="wordsTable ${escapeHtml(opts.classList.join(' ')) || ''}">
      <thead class="wordsTable__header">
        <tr class="wordsTable__row">
          <th class="wordsTable__cell">
            English
          </th>
          <th class="wordsTable__cell">
            Русский
          </th>
        </tr>
      </thead>
      <tbody class="wordsTable__body">
        ${rows}
      </tbody>
    </table>
  `;
}

module.exports = { render, needData }